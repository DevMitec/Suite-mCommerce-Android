package mx.com.mitec.suitemcommercedemo;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.mitec.suitemcommerce.beans.Bean3DS;
import com.mitec.suitemcommerce.beans.BeanPaymentResponse;
import com.mitec.suitemcommerce.beans.BeanPaymentWithToken;
import com.mitec.suitemcommerce.beans.BeanTokenization;
import com.mitec.suitemcommerce.beans.BeanTokenizeResponse;
import com.mitec.suitemcommerce.beans.SuiteError;
import com.mitec.suitemcommerce.controller.SuiteController;
import com.mitec.suitemcommerce.controller.SuiteControllerDelegate;
import com.mitec.suitemcommerce.utilities.Currency;
import com.mitec.suitemcommerce.utilities.Environment;
import com.mitec.suitemcommerce.utilities.Utilities;

public class TokenPayActivity extends AppCompatActivity implements View.OnClickListener, SuiteControllerDelegate {

    /*View variables*/
    private EditText editToken, editAmount, editReference;
    private Button buttonPay;
    private AlertDialog.Builder dialog;
    private ProgressDialog progressDialog;

    /*Controller variables*/
    private SuiteController suiteController;

    /*Operation variables*/
    private Bean3DS bean3DS;
    private BeanTokenization beanTokenization;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_token_pay);

        init();
    }

    @Override
    protected void onResume(){
        super.onResume();

        editAmount.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                buttonPay.setText("Pay $ " + editAmount.getText().toString());
            }

        });
    }

    private void init(){
        /*Toolbar variables*/
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("Token Pay");

        /*View variables*/
        editToken = (EditText)findViewById(R.id.token);
        editAmount = (EditText)findViewById(R.id.amount);
        editReference = (EditText)findViewById(R.id.reference);
        buttonPay = (Button)findViewById(R.id.buttonSell);
        buttonPay.setOnClickListener(this);

        dialog = new AlertDialog.Builder(this);
        dialog.setPositiveButton("Accept", null);
        dialog.setCancelable(false);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Procesando operación");


        /*Controller variables*/
        suiteController = new SuiteController(Environment.SANDBOX, this, this);
        bean3DS = new Bean3DS();
        beanTokenization = new BeanTokenization();

    }


    private void dialogAlert(String title, String message){

        dialog.setTitle(title);
        dialog.setMessage(message);

        this.runOnUiThread(new Runnable() {
            public void run() {
                if (!TokenPayActivity.this.isFinishing()) {
                    dialog.show();
                }
            }
        });
    }


    @Override
    public void onClick(View v) {
        if(v.getId() == buttonPay.getId()){

            /** SANDBOX */
            beanTokenization.setCompany("llenar");
            beanTokenization.setBranch("llenar");
            beanTokenization.setCountry("llenar");
            beanTokenization.setUser("llenar");
            beanTokenization.setPassword("llenar");
            beanTokenization.setMerchant("llenar");
            beanTokenization.setReference(editReference.getText().toString());
            beanTokenization.setOperationType("6");
            beanTokenization.setToken(editToken.getText().toString());
            beanTokenization.setAmount(editAmount.getText().toString());
            beanTokenization.setCurrency(Currency.MXN);

            bean3DS.setCompany("llenar");
            bean3DS.setBranch("llenar");
            bean3DS.setCountry("llenar");
            bean3DS.setUser("llenar");
            bean3DS.setPassword("llenar");
            bean3DS.setMerchant("llenar");
            bean3DS.setCurrency(Currency.MXN);
            bean3DS.setAuthKey("llenar");
            bean3DS.setReference("");

            progressDialog.show();

            /*Token pay*/
            new SndPayWithToken().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void didFinishPayProcess(String response, SuiteError suiteError) {
    }

    @Override
    public void didFinishAuthenticationProcess(BeanTokenizeResponse beanTokenizeResponse, SuiteError suiteError) {
    }

    @Override
    public void didFinishTokenizeTransaction(BeanPaymentWithToken beanPaymentWithToken, SuiteError suiteError){
        progressDialog.dismiss();
        if(beanPaymentWithToken != null){
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra("beanPaymentWithToken", beanPaymentWithToken);
            startActivity(intent);
            finish();
        }
        if(suiteError != null)
            dialogAlert("Error", suiteError.getError());
    }

    @Override
    public void canceledProcessByUser(){
        progressDialog.dismiss();
        dialogAlert("Operación", "Operación cancelada por el usuario");
    }

    private class SndPayWithToken extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            suiteController.sndPayWithToken(beanTokenization, bean3DS);
            return null;
        }
    }
}
