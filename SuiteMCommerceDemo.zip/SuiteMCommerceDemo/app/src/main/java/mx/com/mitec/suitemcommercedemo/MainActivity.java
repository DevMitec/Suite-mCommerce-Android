package mx.com.mitec.suitemcommercedemo;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import com.mitec.suitemcommerce.beans.Bean3DS;
import com.mitec.suitemcommerce.beans.BeanPaymentWithToken;
import com.mitec.suitemcommerce.beans.BeanTokenization;
import com.mitec.suitemcommerce.beans.BeanTokenizeResponse;
import com.mitec.suitemcommerce.beans.SuiteError;
import com.mitec.suitemcommerce.controller.SuiteController;
import com.mitec.suitemcommerce.controller.SuiteControllerDelegate;
import com.mitec.suitemcommerce.utilities.Currency;
import com.mitec.suitemcommerce.utilities.Environment;
import com.mitec.suitemcommerce.utilities.Utilities;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SuiteControllerDelegate {

    /*View variables*/
    private Button buttonWebPay, buttonAuthenticate, buttonPayWithToken;
    private AlertDialog.Builder dialog;
    private static ProgressDialog progressDialog;

    /*SuiteController*/
    private SuiteController suiteController;
    private Environment environment;

    /*Operation variables*/
    private Bean3DS bean3DS;
    private BeanTokenization beanTokenization;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    private void init(){
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Suite MCommerce Demo");

        buttonWebPay = (Button)findViewById(R.id.buttonSell);
        buttonAuthenticate = (Button)findViewById(R.id.buttonAuthenticate);
        buttonPayWithToken = (Button)findViewById(R.id.buttonSellWithToken);
        buttonWebPay.setOnClickListener(this);
        buttonAuthenticate.setOnClickListener(this);
        buttonPayWithToken.setOnClickListener(this);

        dialog = new AlertDialog.Builder(this);
        dialog.setPositiveButton("Aceptar", null);
        dialog.setCancelable(false);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Procesando operación");

        environment = Environment.SANDBOX;
        bean3DS = new Bean3DS();
        beanTokenization = new BeanTokenization();


    }

    @Override
    public void onClick(View v) {
        Intent intent;
        if(v.getId() == buttonWebPay.getId()){
            intent = new Intent(MainActivity.this, WebPayActivity.class);
            startActivity(intent);
        }
        else if(v.getId() == buttonAuthenticate.getId()){
            /** SANDBOX */
            bean3DS.setCompany("llenar");
            bean3DS.setBranch("llenar");
            bean3DS.setCountry("llenar");
            bean3DS.setUser("llenar");
            bean3DS.setPassword("llenar");
            bean3DS.setMerchant("llenar");
            bean3DS.setCurrency(Currency.MXN);
            bean3DS.setAuthKey("llenar");
            bean3DS.setReference("");

            beanTokenization.setCompany("llenar");
            beanTokenization.setBranch("llenar");
            beanTokenization.setCountry("llenar");
            beanTokenization.setUser("llenar");
            beanTokenization.setPassword("llenar");
            beanTokenization.setMerchant("llenar");
            beanTokenization.setOperationType("6");
            beanTokenization.setReference("");
            beanTokenization.setCurrency(Currency.MXN);


            progressDialog.show();
            suiteController = new SuiteController(environment, this, this);
            /*Authenticate process*/
            new Authenticate().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        }
        else if(v.getId() == buttonPayWithToken.getId()){
            intent = new Intent(MainActivity.this, TokenPayActivity.class);
            startActivity(intent);
        }
    }

    private void dialogAlert(String title, String message){

        dialog.setTitle(title);
        dialog.setMessage(message);

        this.runOnUiThread(new Runnable() {
            public void run() {
                if (!MainActivity.this.isFinishing()) {
                    dialog.show();
                }
            }
        });
    }

    @Override
    public void onBackPressed(){
        finish();
    }

    @Override
    public void didFinishPayProcess(String response, SuiteError suiteError) {

    }


    @Override
    public void didFinishAuthenticationProcess(BeanTokenizeResponse beanTokenizeResponse, SuiteError suiteError){
        progressDialog.dismiss();
        if(beanTokenizeResponse != null){
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra("beanTokenizeResponse", beanTokenizeResponse);
            startActivity(intent);
        }
        if(suiteError != null) {
            Utilities.println("didFinishAuthenticationProcess " + suiteError.toString());
            dialogAlert("Error", suiteError.getError());
        }
    }

    @Override
    public void didFinishTokenizeTransaction(BeanPaymentWithToken beanPaymentWithToken, SuiteError suiteError){
    }

    @Override
    public void canceledProcessByUser() {
        progressDialog.dismiss();
        dialogAlert("Operación", "Operación cancelada por el usuario");
    }

    private class Authenticate extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            suiteController.authenticate(beanTokenization, bean3DS);
            return null;
        }
    }
}
