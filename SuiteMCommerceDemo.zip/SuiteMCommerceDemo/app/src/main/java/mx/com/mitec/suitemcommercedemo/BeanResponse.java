package mx.com.mitec.suitemcommercedemo;

import com.mitec.suitemcommerce.utilities.Utilities;

import java.io.Serializable;

/**
 * Created by eperez on 20/04/2016.
 */
public class BeanResponse implements Serializable {

    private String reference;
    private String response;
    private String auth;
    private String error;
    private String ccName;
    private String ccNum;
    private String amount;
    private String type;
    private static final long serialVersionUID = 1L;

    public BeanResponse(String response){
        Utilities utilities = new Utilities(null);

        reference = utilities.getDataXML("referencia", response);
        this.response = utilities.getDataXML("response", response);
        auth = utilities.getDataXML("aut", response);
        error = utilities.getDataXML("error", response);
        ccName = utilities.getDataXML("ccName", response);
        ccNum = utilities.getDataXML("ccNum", response);
        amount = utilities.getDataXML("amount", response);
        type = utilities.getDataXML("type", response);
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getAuth() {
        return auth;
    }

    public void setAuth(String auth) {
        this.auth = auth;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getCcName() {
        return ccName;
    }

    public void setCcName(String ccName) {
        this.ccName = ccName;
    }

    public String getCcNum() {
        return ccNum;
    }

    public void setCcNum(String ccNum) {
        this.ccNum = ccNum;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @Override
    public String toString() {
        return "BeanPaymentResponse{" +
                "reference='" + reference + '\'' +
                ", response='" + response + '\'' +
                ", auth='" + auth + '\'' +
                ", error='" + error + '\'' +
                ", ccName='" + ccName + '\'' +
                ", ccNum='" + ccNum + '\'' +
                ", amount='" + amount + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
