package mx.com.mitec.suitemcommercedemo;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.mitec.suitemcommerce.beans.BeanPaymentResponse;
import com.mitec.suitemcommerce.beans.BeanPaymentWithToken;
import com.mitec.suitemcommerce.beans.BeanTokenizeResponse;
import com.mitec.suitemcommerce.beans.SuiteError;
import com.mitec.suitemcommerce.controller.SuiteController;
import com.mitec.suitemcommerce.controller.SuiteControllerDelegate;
import com.mitec.suitemcommerce.utilities.AESEncryption;
import com.mitec.suitemcommerce.utilities.Currency;
import com.mitec.suitemcommerce.utilities.Environment;
import com.mitec.suitemcommerce.utilities.PaymentType;
import com.mitec.suitemcommerce.utilities.Utilities;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

import java.util.ArrayList;

public class WebPayActivity extends AppCompatActivity implements View.OnClickListener, SuiteControllerDelegate {

    /*View variables*/
    private EditText editAmount, editReference;
    private Button buttonPay;
    private Spinner spnPaymentMode, spnCurrency;
    private Intent intent;
    private AlertDialog.Builder dialog;
    private ProgressDialog progressDialog;

    /*Payment variables*/
    private String paymentMode, currencyMode;
    private PaymentType paymentType;
    private Currency currency;
    private String company;
    private String APIKey;
    private String xmlM, xmlA;
    private String amount, reference;

    /*Controller variables*/
    private SuiteController suiteController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_pay);

        init();
    }

    @Override
    protected void onResume(){
        super.onResume();

        setPaymentMode();
        setCurrency();
        setAmountButton();
    }

    private void init(){
        /*Toolbar variables*/
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("Web Pay");

        /*View variables*/
        editAmount = (EditText)findViewById(R.id.amount);
        editReference = (EditText)findViewById(R.id.reference);
        buttonPay = (Button)findViewById(R.id.buttonSell);
        buttonPay.setOnClickListener(this);
        spnPaymentMode = (Spinner)findViewById(R.id.spnPaymentType);
        spnCurrency = (Spinner)findViewById(R.id.spnCurrency);

        dialog = new AlertDialog.Builder(this);
        dialog.setPositiveButton("Accept", null);
        dialog.setCancelable(false);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Procesando operación");

        ArrayList listPaymentType = new ArrayList<String>();
        listPaymentType.add("Contado");
        listPaymentType.add("3meses");
        listPaymentType.add("6meses");
        listPaymentType.add("9meses ");
        listPaymentType.add("12meses");

        ArrayList listCurrency = new ArrayList<String>();
        listCurrency.add("MXN");
        listCurrency.add("USD");

        int spinner = R.layout.spinner_layout;
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, spinner, R.id.textview, listPaymentType);
        adapter.setDropDownViewResource(spinner);
        spnPaymentMode.setAdapter(adapter);

        adapter = new ArrayAdapter<String>(this, spinner, R.id.textview, listCurrency);
        adapter.setDropDownViewResource(spinner);
        spnCurrency.setAdapter(adapter);


        /** SANDBOX */
        company = "D594";
        APIKey = "0DC5320E6EC7A484B0B0841CBE26EF08";
        xmlM = "5647586E6A376D4C4A384452524F43744E424152362B4147524167SNDBX4646C305554677254515145657574623445783768725A3774694869365A6E6A6C716D56556B6F44362F7848634D410A363562674B50SNDBXC7643776F2F6C714C314A6F70326F36784E66644D2F6E64686367595278337434336D3567576E657971414554306A6B467378703071683669595SNDBX6770374C6855620A4433514F6A5A7166574371326A3041505536364C78326838342F762F356756592F6B61562B564A796938646F664F50372FSNDBX7325532483064616F53513D3D";
        
        /*Controller variables*/
        suiteController = new SuiteController(Environment.SANDBOX, this, this);

    }

    private void setPaymentMode(){
        spnPaymentMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                paymentMode = parent.getSelectedItem().toString();
                if(paymentMode.equals("Contado")){
                    paymentType = PaymentType.C;
                }
                else if(paymentMode.equals("3meses")){
                    paymentType = PaymentType.to3M;
                }
                else if(paymentMode.equals("6meses")){
                    paymentType = PaymentType.to6M;
                }
                else if(paymentMode.equals("9meses")){
                    paymentType = PaymentType.to9M;
                }
                else if(paymentMode.equals("12meses")){
                    paymentType = PaymentType.to12M;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                paymentType = PaymentType.C;
            }
        });
    }

    private void setCurrency(){
        spnCurrency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currencyMode = parent.getSelectedItem().toString();
                if (currencyMode.equals("MXN"))
                    currency = Currency.MXN;
                else if (currencyMode.equals("USD"))
                    currency = Currency.USD;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                currency = Currency.MXN;
            }
        });
    }

    private void setAmountButton(){

        super.onResume();

        editAmount.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                buttonPay.setText("Pay $ " + editAmount.getText().toString());
            }

        });

    }

    private void dialogAlert(String title, String message){

        dialog.setTitle(title);
        dialog.setMessage(message);

        this.runOnUiThread(new Runnable() {
            public void run() {
                if (!WebPayActivity.this.isFinishing()) {
                    dialog.show();
                }
            }
        });
    }


    @Override
    public void onClick(View v) {
        if(v.getId() == buttonPay.getId()){
            amount = editAmount.getText().toString();
            reference = editReference.getText().toString();

            xmlA = generateXMLA(paymentType, amount, reference, currency);
            byte[] key = new byte[0];;
            try {
                key = Hex.decodeHex(this.APIKey.toCharArray());
            } catch (DecoderException e) {
                Log.e("Exception***", e.getMessage());
                e.printStackTrace();
            }
            try {
                xmlA = AESEncryption.cifrar(xmlA, key, "CBC", "PKCS5Padding", new Base64());
            } catch (Exception e) {
                Log.e("Exception***", e.getMessage());
                e.printStackTrace();
            }
            xmlA = String.valueOf(Hex.encodeHex(xmlA.getBytes()));
            Utilities.println("XMLA " + xmlA);
            /*Web pay*/
            new WebPay().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void didFinishPayProcess(String response, SuiteError suiteError) {
        progressDialog.dismiss();
        if(response != null) {

            try {
                response = new String(Hex.decodeHex(response.toCharArray()));
                response = AESEncryption.descifrar(response, Hex.decodeHex(APIKey.toCharArray()), "CBC", "PKCS5Padding", new Base64());
                BeanResponse beanResponse = new BeanResponse(response);

                intent = new Intent(this, ResultActivity.class);
                intent.putExtra("beanPaymentResponse", beanResponse);
                startActivity(intent);
                finish();
            }catch(Exception e){
                e.printStackTrace();
            }


        }
        if(suiteError != null){
            dialogAlert("Error", suiteError.getError());
        }
    }


    @Override
    public void didFinishAuthenticationProcess(BeanTokenizeResponse beanTokenizeResponse, SuiteError suiteError) {
    }

    @Override
    public void didFinishTokenizeTransaction(BeanPaymentWithToken beanPaymentWithToken, SuiteError suiteError){
    }

    @Override
    public void canceledProcessByUser(){
        progressDialog.dismiss();
        dialogAlert("Operation", "Operacion cancelada por el usuario");
    }

    private class WebPay extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            suiteController.sndPay(company, xmlA, xmlM);
            return null;
        }
    }

    /**payment xml*/
    public String generateXMLA(PaymentType paymentType, String amount, String reference, Currency currency){
        String XMLA = new String();
        String urlResponse = "https://suitemcommerce.com";

        XMLA +="<tpPago>" + paymentType.getValue() + "</tpPago>";
        XMLA +="<amount>" + amount + "</amount>";
        XMLA +="<urlResponse>" + urlResponse + "</urlResponse>";
        XMLA +="<referencia>" + reference + "</referencia>";
        XMLA +="<moneda>" + currency + "</moneda>";
        XMLA +="<date_hour>"+Utilities.getFechaActual_ISO8601()+"</date_hour>";

        Utilities.println("XMLA " + XMLA);
        return XMLA;
    }

}
