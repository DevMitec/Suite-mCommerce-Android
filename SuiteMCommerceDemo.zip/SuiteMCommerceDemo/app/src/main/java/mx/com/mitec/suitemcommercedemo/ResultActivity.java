package mx.com.mitec.suitemcommercedemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mitec.suitemcommerce.beans.BeanPaymentWithToken;
import com.mitec.suitemcommerce.beans.BeanTokenizeResponse;

public class ResultActivity extends AppCompatActivity implements View.OnClickListener{

    /*Payment response*/
    private ImageView imageResult;
    private TextView reference, response, auth, error, ccName, ccNum, amount, type;
    private BeanResponse beanPaymentResponse;

    /*Token response*/
    private BeanTokenizeResponse beanTokenizeResponse;

    /*Payment with token*/
    private BeanPaymentWithToken beanPaymentWithToken;

    private Button buttonAccept;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        init();
    }

    private void init() {
        /*Toolbar variables*/
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("Result");

        /*View variables*/
        imageResult = (ImageView)findViewById(R.id.imageResponse);
        reference = (TextView)findViewById(R.id.reference);
        response = (TextView)findViewById(R.id.response);
        auth = (TextView)findViewById(R.id.auth);
        error = (TextView)findViewById(R.id.error);
        ccName = (TextView)findViewById(R.id.name);
        ccNum = (TextView)findViewById(R.id.number);
        amount = (TextView)findViewById(R.id.amount);
        type = (TextView)findViewById(R.id.type);
        buttonAccept = (Button)findViewById(R.id.btnAccepResult);
        buttonAccept.setOnClickListener(this);

        Intent intent = getIntent();
        if(intent != null){

            beanPaymentResponse = (BeanResponse)intent.getSerializableExtra("beanPaymentResponse");
            beanTokenizeResponse = (BeanTokenizeResponse)intent.getSerializableExtra("beanTokenizeResponse");
            beanPaymentWithToken = (BeanPaymentWithToken)intent.getSerializableExtra("beanPaymentWithToken");
            LinearLayout linearLayoutError = (LinearLayout)findViewById(R.id.layoutError);
            LinearLayout linearLayoutAuth = (LinearLayout)findViewById(R.id.layoutAuth);
            LinearLayout linearLayoutNumber = (LinearLayout)findViewById(R.id.layoutNumber);
            LinearLayout linearLayoutType = (LinearLayout)findViewById(R.id.layoutType);
            LinearLayout linearLayoutName = (LinearLayout)findViewById(R.id.layoutName);
            LinearLayout linearLayoutAmount = (LinearLayout)findViewById(R.id.layoutAmount);
            LinearLayout linearLayoutReference = (LinearLayout)findViewById(R.id.layoutReference);

            /**Payment response*/
            if(beanPaymentResponse != null) {
                if (beanPaymentResponse.getResponse().equals("approved")) {
                    imageResult.setImageDrawable(getResources().getDrawable(R.drawable.ic_approved));
                    linearLayoutError.setVisibility(View.GONE);
                } else {
                    linearLayoutError.setVisibility(View.VISIBLE);
                    linearLayoutAuth.setVisibility(View.GONE);
                    linearLayoutNumber.setVisibility(View.GONE);
                    linearLayoutType.setVisibility(View.GONE);
                    linearLayoutAmount.setVisibility(View.GONE);
                }

                reference.setText(beanPaymentResponse.getReference());
                response.setText(beanPaymentResponse.getResponse());
                auth.setText(beanPaymentResponse.getAuth());
                error.setText(beanPaymentResponse.getError());
                ccName.setText(beanPaymentResponse.getCcName());
                ccNum.setText(beanPaymentResponse.getCcNum());
                amount.setText(beanPaymentResponse.getAmount());
                type.setText(beanPaymentResponse.getType());
            }
            /**Tokenize response*/
            if(beanTokenizeResponse != null){
                if(beanTokenizeResponse.getNbResponse().equals("success")){
                    imageResult.setImageDrawable(getResources().getDrawable(R.drawable.ic_approved));
                    linearLayoutError.setVisibility(View.GONE);
                }
                else{
                    linearLayoutReference.setVisibility(View.GONE);

                }
                TextView labelRefence = (TextView)findViewById(R.id.labelReference);
                labelRefence.setText("Token");
                reference.setText(beanTokenizeResponse.getToken());
                response.setText(beanTokenizeResponse.getNbResponse());

                linearLayoutAuth.setVisibility(View.GONE);
                linearLayoutNumber.setVisibility(View.GONE);
                linearLayoutType.setVisibility(View.GONE);
                linearLayoutError.setVisibility(View.GONE);
                linearLayoutName.setVisibility(View.GONE);
                linearLayoutAmount.setVisibility(View.GONE);
            }
            /**Payment with token response*/
            if(beanPaymentWithToken != null){
                if(beanPaymentWithToken.getResponse().equals("approved")){
                    imageResult.setImageDrawable(getResources().getDrawable(R.drawable.ic_approved));
                    linearLayoutError.setVisibility(View.GONE);
                    linearLayoutName.setVisibility(View.GONE);
                    linearLayoutNumber.setVisibility(View.GONE);
                    TextView labelType = (TextView)findViewById(R.id.labelType);
                    labelType.setText("Folio");
                    type.setText(beanPaymentWithToken.getFolio());
                }
                else{
                    linearLayoutAuth.setVisibility(View.GONE);
                    linearLayoutNumber.setVisibility(View.GONE);
                    linearLayoutType.setVisibility(View.GONE);
                    linearLayoutName.setVisibility(View.GONE);
                    linearLayoutAmount.setVisibility(View.GONE);
                }
                reference.setText(beanPaymentWithToken.getReference());
                response.setText(beanPaymentWithToken.getResponse());
                if(beanPaymentWithToken.getResponse().equals("denied"))
                    error.setText(beanPaymentWithToken.getCdResponse());
                else
                    error.setText(beanPaymentWithToken.getNbError());
                amount.setText(beanPaymentWithToken.getAmount());
                reference.setText(beanPaymentWithToken.getReference());
                auth.setText(beanPaymentWithToken.getAuth());
            }

        }
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == buttonAccept.getId())
            finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

}
